create function "GetSimilarUsers"("emailArg" text, "nicknameArg" text) returns SETOF "User"
  language plpgsql
as
$$
DECLARE
BEGIN
    RETURN QUERY SELECT * FROM public."User" Where  nickname="nicknameArg"::citext OR email="emailArg"::citext ;
END
$$;

alter function "GetSimilarUsers"(text, text) owner to postgres;

