create function "CreateOrGetThread"("slugArg" citext, "authorArg" citext, "createdArg" text, "messageArg" text, "forumArg" citext, "titleArg" text) returns SETOF "Thread"
  language plpgsql
as
$$
DECLARE
  threadRow      "Thread"%ROWTYPE;
  thread_counter integer := 0;
  userRow        public."User"%ROWTYPE;
  user_counter   integer := 0;
  time_stamp     timestamptz;
  thread_slug    text;
  forum_row      citext;
  forum_counter  integer := 0;
  temp_counter INTEGER:=0;
BEGIN
  SELECT count(*) INTO thread_counter FROM public."Thread" WHERE slug = "slugArg"::citext;
  if thread_counter <> 0 THEN
    RAISE unique_violation;
    return;
  end if;

  SELECT count(*) INTO user_counter FROM public."User" WHERE nickname = "authorArg"::citext;
  if user_counter = 0 THEN
    RAISE no_data_found;
    return;
  end if;
  
  if "createdArg" = '' then
    time_stamp = now();
  else
    time_stamp = "createdArg";
  end if;

  if "slugArg" = '' then
    thread_slug = uuid_generate_v4()::citext;
    if thread_slug = '' then
      thread_slug = 'uid_generate_v4()';
    end if;
  else
    thread_slug = "slugArg";
  end if;

  SELECT "Forum".slug INTO forum_row FROM public."Forum" WHERE slug = "forumArg"::citext;
  SELECT count(*) INTO forum_counter FROM public."Forum" WHERE slug = "forumArg"::citext;


  if forum_counter = 0 then
    raise no_data_found;
    return;
  end if;

  SELECT * INTO userRow FROM public."User" WHERE nickname = "authorArg"::citext;
  INSERT INTO public."Thread" (author, created, forum, "message", slug, title, votes)
  VALUES (userRow.nickname::citext, time_stamp::timestamptz, forum_row::citext, "messageArg", thread_slug::citext,
          "titleArg", 0);
          
  
  temp_counter := (SELECT count(*) FROM public.forumuser WHERE forum =forum_row::citext AND "user"  =userRow.nickname::citext);
    if temp_counter =0 then
      INSERT INTO public.forumuser ("forum","user") VALUES(forum_row::citext, userRow.nickname::citext);
    end if;       
  UPDATE public."Forum" SET threads = threads+1 where slug = forum_row::citext;
  RETURN QUERY SELECT * FROM public."Thread" WHERE slug = thread_slug::citext;

END
$$;

alter function "CreateOrGetThread"(citext, citext, text, text, citext, text) owner to postgres;

