create function "GetThreadDetails"(thread_slug citext, thread_id integer) returns SETOF "Thread"
  language plpgsql
as
$$
DECLARE
  treadSlug citext;
  thread_counter integer:=0;
BEGIN
    if thread_id = 0 then
    SELECT count(*) INTO thread_counter from public."Thread" where slug = thread_slug::citext;
    SELECT slug INTO treadSlug from public."Thread" where slug = thread_slug::citext;
    end if;

  -- CHECK IF THREAD BY ID EXISTS
  if thread_slug = '' then
    SELECT count(*) INTO thread_counter from public."Thread" where id = thread_id;
    SELECT slug INTO treadSlug from public."Thread" where id = thread_id;
  end if;

  if thread_counter = 0 then
    RAISE EXCEPTION 'THREAD NOT FOUND  slug  %, id %', thread_slug::text,thread_id::text USING ERRCODE = 'no_data_found';
  end if;

  RETURN QUERY SELECT * FROM public."Thread" WHERE slug=treadSlug::citext;
END
$$;

alter function "GetThreadDetails"(citext, integer) owner to postgres;

