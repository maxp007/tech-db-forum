create function "UpdateUserProfile"("aboutArg" text, "emailArg" text, "fullnameArg" text, "nicknameArg" text) returns SETOF "User"
  language plpgsql
as
$$
DECLARE
    v_count integer := 0;
BEGIN
    SELECT count(*) into v_count FROM public."User" Where nickname = "nicknameArg"::citext;

    IF v_count = 0 THEN
        RAISE EXCEPTION no_data_found;
    ELSE
        if "emailArg" <> '' then
            UPDATE public."User" SET email = COALESCE("emailArg"::citext, email) WHERE nickname = "nicknameArg"::citext;
        end if;

        if "aboutArg" <> '' then
            UPDATE public."User" SET about = COALESCE("aboutArg"::citext, email) WHERE nickname = "nicknameArg"::citext;
        end if;

        if "fullnameArg" <> '' then
            UPDATE public."User" SET fullname = COALESCE("fullnameArg"::citext, email) WHERE nickname = "nicknameArg"::citext;
        end if;
        
        RETURN QUERY SELECT * FROM public."User" Where nickname = "nicknameArg"::citext;
    END IF;

END
$$;

alter function "UpdateUserProfile"(text, text, text, text) owner to postgres;

