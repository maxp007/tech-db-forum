create function "GetServiceStatus"() returns "Status"
  language plpgsql
as
$$
DECLARE
  status_output ServiceStatus;
BEGIN

  status_output.forum :=COALESCE ((SELECT count(*) from public."Forum"), 0::INTEGER);
  status_output.post := COALESCE((SELECT count(*) from public."Post"), 0::INTEGER);
  status_output.thread := COALESCE((SELECT count(*) from public."Thread"), 0::INTEGER);
  status_output."user" := COALESCE((SELECT count(*) from public."User"), 0::INTEGER);

  return "status_output";

END
$$;

alter function "GetServiceStatus"() owner to postgres;

