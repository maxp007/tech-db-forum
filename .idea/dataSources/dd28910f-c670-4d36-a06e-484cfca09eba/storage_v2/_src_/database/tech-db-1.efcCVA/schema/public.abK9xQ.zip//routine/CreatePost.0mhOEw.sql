create function "CreatePost"(postsarray type_in_post[]) returns SETOF "Post"
  language plpgsql
as
$$
DECLARE
    in_post type_in_post;
    current_date_variable timestamptz:=now();
    forum_slug citext;
    thread_identifier integer;
    posts_setof  "Post"[];
    out_post  "Post";
BEGIN
    FOR i IN 1 .. array_upper(postsArray, 1) LOOP
        in_post := postsArray[i];

        if in_post.thread_slug <> ''::citext then
            select forum, id into forum_slug, thread_identifier from public."Thread" where slug=in_post.thread_slug;
        elsif in_post.thread_id <> 0 then
            thread_identifier :=in_post.thread_id;
            select forum into forum_slug from public."Thread" where id=in_post.thread_id;
        else
         raise no_data_found;
         EXIT;
        end if;
        INSERT INTO out_post (author, created, forum, "isEdited", message, parent, thread)
        VALUES (in_post.author::citext,current_date_variable::timestamptz,forum_slug::citext, false,in_post.messag,0,thread_identifier);

        INSERT INTO public."Post" (author, created, forum, "isEdited", message, parent, thread)
        VALUES (in_post.author::citext,current_date_variable::timestamptz,forum_slug::citext, false,in_post.messag,0,thread_identifier);

    END LOOP;
    return  QUERY  SELECT * FROM public."Post" WHERE created  =current_date_variable AND thread=thread_identifier;
END
$$;

alter function "CreatePost"(type_in_post[]) owner to postgres;

