create function clearalldata() returns SETOF "Status"
  language plpgsql
as
$$
DECLARE
  BEGIN
  DELETE FROM  public."Error" CASCADE;
  DELETE FROM public."Vote" CASCADE;
  DELETE FROM public."forumuser" CASCADE;
  DELETE FROM public."Post" CASCADE;
  DELETE FROM public."Thread" CASCADE;

  DELETE FROM public."Forum" CASCADE;
  DELETE FROM public."Status" CASCADE;
  DELETE FROM public."User" CASCADE;
  
  RETURN QUERY SELECT * FROM public."GetServiceStatus"();
end
$$;

alter function clearalldata() owner to postgres;

