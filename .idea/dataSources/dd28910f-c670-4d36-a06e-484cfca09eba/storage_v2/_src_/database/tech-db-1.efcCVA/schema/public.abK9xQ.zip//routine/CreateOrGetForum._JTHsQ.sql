create function "CreateOrGetForum"("titleArg" text, "slugArg" text, "userArg" citext) returns SETOF "Forum"
  language plpgsql
as
$$
DECLARE
    forumRow "Forum"%ROWTYPE;
    forum_counter integer :=0;
    userRow public."User"%ROWTYPE;
BEGIN
    SELECT count(*) INTO forum_counter FROM public."Forum" WHERE slug="slugArg"::citext;
    if forum_counter <> 0 THEN
        RAISE unique_violation;
    ELSE
        SELECT * INTO userRow FROM public."User" WHERE nickname="userArg"::citext;
        INSERT INTO public."Forum" ("posts","slug","threads","title","user")
        VALUES (0,"slugArg",0,"titleArg"::citext,userRow.nickname::citext);
        RETURN QUERY SELECT * FROM public."Forum" WHERE slug="slugArg"::citext;
   
    end if;
END
$$;

alter function "CreateOrGetForum"(text, text, citext) owner to postgres;

