create function "GetForumUsers"(forum_slug citext, limitarg integer, sincearg citext, descarg text) returns SETOF "User"
  language plpgsql
as
$$
DECLARE
temp_counter INTEGER:=0;
  limit_Arg INTEGER:=0;
BEGIN
 temp_counter:= (SELECT count(*) FROM public."Forum" WHERE slug=  forum_slug::citext);
  if temp_counter=0 then
    RAISE EXCEPTION no_data_found;
  end if;
  
  if limitarg = 0 then
    limit_Arg:=100000000;
    else 
    limit_Arg:=limitarg;
  end if;
  
  if descArg = 'true' then
    if sincearg = ''
    then
      RETURN QUERY SELECT about,email,fullname,nickname
                   FROM forumuser
                          INNER JOIN
                        public."User" ON "User".nickname = forumuser.user
                   WHERE forum = forum_slug::citext
                   ORDER BY lower(nickname) DESC
                   LIMIT limit_Arg;

    else
      RETURN QUERY SELECT about,email,fullname,nickname
                   FROM forumuser
                          INNER JOIN
                        public."User" ON "User".nickname = forumuser.user
                   WHERE forum = forum_slug::citext
                     AND nickname < sinceArg
                   ORDER BY lower(nickname) DESC
                   LIMIT limit_Arg;

    end if;
  else
    if sincearg = ''
    then
      RETURN QUERY SELECT about,email,fullname,nickname
                   FROM forumuser
                          INNER JOIN
                        public."User" ON "User".nickname = forumuser.user
                   WHERE forum = forum_slug::citext
                   ORDER BY lower(nickname) ASC
                   LIMIT limit_Arg;

    else
      RETURN QUERY SELECT about,email,fullname,nickname
                   FROM forumuser
                          INNER JOIN
                        public."User" ON "User".nickname = forumuser.user
                   WHERE forum = forum_slug::citext
                     AND nickname > sinceArg
                   ORDER BY lower(nickname) ASC
                   LIMIT limit_Arg;

    end if;
  end if;


END
$$;

alter function "GetForumUsers"(citext, integer, citext, text) owner to postgres;

