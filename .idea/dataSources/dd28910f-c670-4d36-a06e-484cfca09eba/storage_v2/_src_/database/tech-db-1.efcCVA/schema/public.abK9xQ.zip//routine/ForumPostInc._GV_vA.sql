create function "ForumPostInc"() returns trigger
  language plpgsql
as
$$
DECLARE 
postCounter "Forum"%ROWTYPE; 
BEGIN 
SELECT * INTO postCounter FROM "Forum" WHERE slug = NEW.forum; 
postCounter.posts := postCounter.posts + 1; 
RETURN NEW; 
END;
$$;

alter function "ForumPostInc"() owner to postgres;

