create function buildtreefromnode(node_id bigint, thread_id bigint) returns SETOF treenode
  language plpgsql
as
$$
DECLARE
  BEGIN
 RETURN QUERY (WITH RECURSIVE tree  AS   (
           SELECT message,
                 id,
                 parent,
                 NULL::varchar AS parent_name,
                 array [id]    AS path
          FROM "Post"
          WHERE id = node_id AND "Post".thread = thread_id
          UNION
          SELECT parent_name,
                 f1.id,
                 f1.parent,
                 tree.message       AS parent_name,
                 tree.path || f1.id AS path
          FROM tree
                 JOIN "Post" f1 ON f1.parent = tree.id
          ) SELECT tree.id, tree.parent,tree.path FROM tree order by path);
end
$$;

alter function buildtreefromnode(bigint, bigint) owner to postgres;

