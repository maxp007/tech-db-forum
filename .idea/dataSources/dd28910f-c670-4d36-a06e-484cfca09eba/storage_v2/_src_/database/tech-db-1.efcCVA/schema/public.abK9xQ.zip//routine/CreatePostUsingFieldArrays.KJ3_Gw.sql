create function "CreatePostUsingFieldArrays"(author_array citext[], message_array text[], parent_array integer[], array_len integer, thread_slug citext, thread_id integer, parent_is_the_same boolean, author_is_the_same boolean) returns SETOF "Post"
  language plpgsql
as
$$
DECLARE
  thread_counter  integer := 0;
  thread_row      public."Thread"%ROWTYPE;
  forum_counter   integer := 0;
  parent_counter  integer := 0;
  author_counter  integer := 0;
  common_parent   integer := 0;
  common_author   text    := '';
  current_date_my timestamptz;
  temp_counter    INTEGER;
BEGIN

  -- CHECK IF THREAD BY SLUG EXISTS
  current_date_my := now();
  if thread_id = 0 then
    SELECT count(*) INTO thread_counter from public."Thread" where slug = thread_slug::citext;
    SELECT * INTO thread_row from public."Thread" where slug = thread_slug::citext;
  end if;

  -- CHECK IF THREAD BY ID EXISTS
  if thread_slug = '' then
    SELECT count(*) INTO thread_counter from public."Thread" where id = thread_id;
    SELECT * INTO thread_row from public."Thread" where id = thread_id;
  end if;

  if thread_counter = 0 OR thread_row IS NULL then
    RAISE EXCEPTION no_data_found;
  end if;

  if array_length(message_array, 1) IS NULL
  then
    RETURN;
  end if;
  -- CHECK IF FORUM BY SLUG EXISTS
  SELECT count(*) INTO forum_counter from public."Forum" where slug = thread_row.forum::citext;
  if forum_counter = 0 then
    RAISE EXCEPTION no_data_found;
  end if;

  if author_is_the_same = true AND parent_is_the_same = true then
    common_parent = parent_array [ 1];
    common_author = author_array [ 1];
    if common_parent <> 0 then
      temp_counter := (SELECT thread FROM "Post" WHERE common_parent = id);
      if temp_counter <> thread_row.id OR temp_counter IS NULL then
        raise exception raise_exception;
      end if;

    end if;
    INSERT INTO public."Post" ("author", "created", "forum", "isEdited", "message", "parent", "thread")
    VALUES (common_author, current_date_my, thread_row.forum, false, unnest(message_array), common_parent,
            thread_row.id);
    UPDATE public."Forum"
    SET posts = posts + array_length(message_array, 1)
    where "Forum".slug = thread_row.forum::citext;

    temp_counter := (SELECT count(*)
                     FROM public.forumuser
                     WHERE forum = thread_row.forum::citext
                       AND "user" = common_author::citext);
    if temp_counter = 0 then
      INSERT INTO public.forumuser ("forum", "user") VALUES (thread_row.forum::citext, common_author::citext);
    end if;

    RETURN QUERY SELECT * FROM public."Post" where created = current_date_my;
    return;
  else
    -- IF authors are the same then check it's existance if it not 0, else ok
    if author_is_the_same = true then
      common_author = author_array [ 1];
      if common_author <> '' then
        SELECT count(*) INTO author_counter from public."User" where nickname = common_author::citext;
        if author_counter = 0 then
          RAISE EXCEPTION 'COMMON AUTHOR NOT FOUND  nickname %', common_author USING ERRCODE = 'no_data_found';
        end if;
      end if;
    else
      FOR idx IN 1..array_len
        LOOP
          SELECT count(*) INTO author_counter from public."User" where nickname = author_array [ idx]::citext;
          if author_counter = 0 then
            RAISE EXCEPTION 'VARY AUTHOR NOT FOUND  nickname %', author_array [ idx] USING ERRCODE = 'no_data_found';
          end if;
        END LOOP;
    end if;

    -- IF parents are the same then check it's existance if it not 0, else ok
    if parent_is_the_same = true then
      common_parent = parent_array [ 1];
      if common_parent <> 0 then
        SELECT count(*) INTO parent_counter from public."Post" where id = common_parent::integer;
        if parent_counter = 0 then
          RAISE EXCEPTION 'COMMON PARENT NOT FOUND  common_parent %', common_parent USING ERRCODE = 'no_data_found';
        end if;
      end if;
    else
      FOR idx IN 1..array_len
        LOOP
          if parent_array [ idx] <> 0 then
            temp_counter := (SELECT thread from public."Post" where id = parent_array [ idx]::BIGINT);
            if temp_counter <> thread_row.id OR temp_counter IS NULL then
              RAISE EXCEPTION raise_exception;
            end if;
          end if;
        END LOOP;

      FOR idx IN 1..array_len
        LOOP
          SELECT count(*) INTO parent_counter from public."Post" where id = parent_array [ idx]::BIGINT;
          if parent_counter = 0 AND parent_array [ idx] <> 0 then
            RAISE EXCEPTION 'VARY PARENT NOT FOUND  parent %', parent_array [ idx] USING ERRCODE = 'no_data_found';
          end if;
        END LOOP;
    end if;

    INSERT INTO public."Post" ("author", "created", "forum", "isEdited", "message", "parent", "thread")
    VALUES (unnest(author_array), current_date_my, thread_row.forum, false, unnest(message_array), unnest(parent_array),
            thread_row.id);
    FOR i in 1..array_length(author_array, 1)
      LOOP
        temp_counter := (SELECT count(*)
                         FROM public.forumuser
                         WHERE forum = thread_row.forum::citext
                           AND "user" = author_array [ i]::citext);
        if temp_counter = 0 then
          INSERT INTO public.forumuser ("forum", "user") VALUES (thread_row.forum::citext, author_array [ i]::citext);
        end if;
      end loop;

    UPDATE public."Forum"
    SET posts = posts + array_length(author_array, 1)
    where "Forum".slug = thread_row.forum::citext;

    RETURN QUERY SELECT * FROM public."Post" where created = current_date_my ORDER BY id ASC;
    return;
  end if;
END
$$;

alter function "CreatePostUsingFieldArrays"(citext[], text[], integer[], integer, citext, integer, boolean, boolean) owner to postgres;

