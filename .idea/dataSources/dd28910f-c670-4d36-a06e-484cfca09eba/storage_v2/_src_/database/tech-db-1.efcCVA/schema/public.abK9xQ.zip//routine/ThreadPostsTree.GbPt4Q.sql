create function "ThreadPostsTree"(thread_id integer, limitarg integer, sincearg integer, sortarg text, descarg boolean) returns SETOF "Post"
  language plpgsql
as
$$
DECLARE
  parents_counter integer:=0;
  parents_id_array integer[];
  result_array "Post"[];
  result_id_array bigint[];
  temp_post_row "Post";
BEGIN
  parents_id_array:=ARRAY(SELECT id  FROM public."Post" where (id > 448 AND id < 508 AND parent = 0 AND "Post".thread=thread_id) ORDER BY id ASC) ;
  SELECT * INTO temp_post_row FROM "Post" where id=parents_id_array[1];
  if limitarg>0 then
    result_id_array = array_append(result_id_array, temp_post_row.id);
    end if;
  FOR i in 1..array_length(parents_id_array,1)
  LOOP
  if array_length(parents_id_array,1)=limitarg then
      Return QUERY SELECT * FROM public."Post" WHERE  id = ANY(result_id_array);
    EXIT;
  else
    SELECT * INTO temp_post_row FROM public."Post" where parent  = parents_id_array[i];
  end if;
  end loop;
  SELECT * FROM public."Post" WHERE  id = ANY(ARRAY[448::bigint,449::bigint,507::bigint]);


END
$$;

alter function "ThreadPostsTree"(integer, integer, integer, text, boolean) owner to postgres;

