create function "CreateOrGetUsers"("aboutArg" text, "emailArg" text, "fullnameArg" text, "nicknameArg" text) returns SETOF "User"
  language plpgsql
as
$$
DECLARE

BEGIN
    RETURN QUERY SELECT * FROM public."User" Where nickname = "nicknameArg"::citext OR email = "emailArg"::citext;
    IF NOT FOUND THEN
        INSERT INTO public."User" (about, email, fullname, nickname)
        VALUES ("aboutArg"::citext, "emailArg"::citext, "fullnameArg"::citext, "nicknameArg"::citext);
        RETURN QUERY SELECT * FROM public."User" Where nickname = "nicknameArg"::citext AND email = "emailArg"::citext;
    ELSE
        RAISE unique_violation;
    END IF;
END
$$;

alter function "CreateOrGetUsers"(text, text, text, text) owner to postgres;

